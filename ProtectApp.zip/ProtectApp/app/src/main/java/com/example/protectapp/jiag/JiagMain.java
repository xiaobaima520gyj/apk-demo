package com.example.protectapp.jiag;

import java.io.File;
import java.io.IOException;

public class JiagMain {
    public static void main(String[] args) {
        File testFile = new File("");
        try {
            String path = testFile.getCanonicalPath();
            System.out.println("path:" + path);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
